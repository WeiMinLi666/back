create definer = root@localhost view vt as
select `v`.`visit_id` AS `visit_id`, `t`.`transaction_id` AS `tid`, `v`.`customer_id` AS `customer_id`
from (`wyman`.`visits` `v` left join `wyman`.`transactions` `t` on ((`v`.`visit_id` = `t`.`visit_id`)));

