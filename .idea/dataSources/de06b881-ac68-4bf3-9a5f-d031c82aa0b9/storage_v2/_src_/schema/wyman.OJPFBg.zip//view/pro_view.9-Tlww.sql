create definer = root@localhost view pro_view as
select `wyman`.`product`.`pname` AS `pname`, `wyman`.`product`.`pid` AS `pid`
from `wyman`.`product`;

