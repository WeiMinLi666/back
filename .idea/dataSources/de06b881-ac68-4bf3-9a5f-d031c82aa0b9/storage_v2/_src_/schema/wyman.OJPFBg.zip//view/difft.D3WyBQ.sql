create definer = root@localhost view difft as
select `w1`.`id` AS `id1`, `w1`.`temperature` AS `tem1`
from `wyman`.`weather` `w1`
         join `wyman`.`weather` `w2`
where ((to_days(`w1`.`recordDate`) - to_days(`w2`.`recordDate`)) = 1);

