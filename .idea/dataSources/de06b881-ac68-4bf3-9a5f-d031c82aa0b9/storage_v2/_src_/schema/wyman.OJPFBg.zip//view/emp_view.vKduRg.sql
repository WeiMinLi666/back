create definer = root@localhost view emp_view as
select `e`.`ename` AS `ename`, `d`.`name` AS `name`
from `wyman`.`emp` `e`
         join `wyman`.`dept` `d`
where (`e`.`dept_id` = `d`.`deptno`);

